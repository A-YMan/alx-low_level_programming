#include <stdio.h>

/**
  * main - An entry function
  * Return: Nothing
  */
int main(void)
{
	char string[40];

	printf(" $ ");
	scanf("%s", string);
	printf(" %s\n", string);

	return (0);
}
