# **0x03. C - Debugging**

## General

* What is debugging
* What are some methods of debugging manually
* How to read the error messages

