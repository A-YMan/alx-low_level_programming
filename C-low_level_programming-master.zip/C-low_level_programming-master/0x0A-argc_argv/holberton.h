int _putchar(char c);
