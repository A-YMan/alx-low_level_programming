#ifndef _SUM_H
#define _SUM_H
#define SUM(X, Y) ((X) + (Y))
#endif
