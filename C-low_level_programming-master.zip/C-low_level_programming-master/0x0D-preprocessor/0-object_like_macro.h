#ifndef _OBJECT_LIKE_MACRO_H_
#define _OBJECT_LIKE_MACRO_H_
#define SIZE 1024
#endif /* _OBJECT_LIKE_MACRO_H_ */
