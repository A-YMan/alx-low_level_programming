#ifndef _FUNC_LIKE_MACRO_H
#define _FUNC_LIKE_MACRO_H
#define ABS(x) (((x) < 0) ? -(x) : (x))
#endif
