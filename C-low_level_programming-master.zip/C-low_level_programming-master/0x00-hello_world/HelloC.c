#include <stdio.h>

int main(void)
{
	printf("\n\n");
	printf("  c   c  ccccc  c      c       ccc  \n");
	printf("  c   c  c      c      c      c   c \n");
	printf("  ccccc  ccccc  c      c      c   c \n");
	printf("  c   c  c      c      c      c   c \n");
	printf("  c   c  ccccc  ccccc  ccccc   ccc  \n\n");

	printf("  c   c   ccc   cccc   c      cccc   \n");
	printf("  c   c  c   c  c   c  c      c   c   \n");
	printf("  c c c  c   c  cccc   c      c   c   \n");
	printf("  cc cc  c   c  c   c  c      c   c   \n");
	printf("  c   c   ccc   c   c  ccccc  cccc    \n\n\n");
}
